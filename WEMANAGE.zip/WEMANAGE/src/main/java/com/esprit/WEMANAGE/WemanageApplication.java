package com.esprit.WEMANAGE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WemanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(WemanageApplication.class, args);
	}

}
